1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/eeabdfb325f2f7cc.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"buildId":"iBnHZRVi-JHnfPhFC8Pz8","rsc":["$","$1","c",{"children":[["$",{},null,{}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"loading":null,"isPartial":false}
4:null
