1:"$Sreact.fragment"
2:I[80799,["/_next/static/chunks/2b8e1218b6348671.js","/_next/static/chunks/cca7f2ed83d3bfd6.js","/_next/static/chunks/4d90e636d5dd5d5f.js","/_next/static/chunks/e345af50658a5902.js","/_next/static/chunks/14772d28277878f5.js","/_next/static/chunks/dba3fe432b4c74d7.js","/_next/static/chunks/f9e38b382f5a5452.js"],"default"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/eeabdfb325f2f7cc.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"iBnHZRVi-JHnfPhFC8Pz8","rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/14772d28277878f5.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/dba3fe432b4c74d7.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/f9e38b382f5a5452.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
